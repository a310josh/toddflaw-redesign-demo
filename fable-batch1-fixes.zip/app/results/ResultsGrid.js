'use client';
import { useState } from 'react';
import RESULTS from '../../content/results.json';

const FILTERS = ['All', 'Employment', 'Consumer', 'Class Action', 'Privacy'];

function matches(result, filter) {
  if (filter === 'All') return true;
  if (result.practiceArea === filter) return true;
  if (filter === 'Class Action' && result.tag.toLowerCase().includes('class')) return true;
  return false;
}

export default function ResultsGrid() {
  const [filter, setFilter] = useState('All');
  const visible = RESULTS.filter((r) => matches(r, filter));

  return (
    <>
      <div className="team-filters" style={{ margin: '44px 0 0' }}>
        {FILTERS.map((f) => (
          <button
            key={f}
            className={`chip${filter === f ? ' active' : ''}`}
            onClick={() => setFilter(f)}
          >
            {f}
          </button>
        ))}
      </div>
      <div className="docket-grid reveal-stagger visible">
        {visible.map((result, i) => (
          <div
            key={result.amount + result.tag}
            className={`docket${result.feature ? ' feature' : ''}`}
            style={result.feature ? { gridRow: 'span 2', transitionDelay: `.${(i % 6) + 1}s` } : { transitionDelay: `.${(i % 6) + 1}s` }}
          >
            <div className="ghost">{result.amount}</div>
            <div className="d-tag">{result.tag}</div>
            <div className="d-amt">{result.amount}</div>
            <p>{result.summary}</p>
          </div>
        ))}
      </div>
    </>
  );
}
