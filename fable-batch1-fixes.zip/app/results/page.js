import Link from 'next/link';
import JsonLdGraph from '../components/JsonLdGraph';
import LeadForm from '../components/LeadForm';
import ResultsGrid from './ResultsGrid';

export const metadata = {
  title: 'Case Results',
  description:
    'Notable case results and settlements from the Law Offices of Todd M. Friedman, P.C. Nearly $1 billion recovered for employees and consumers.',
  alternates: { canonical: '/results/' },
};

export default function ResultsPage() {
  return (
    <>
      <JsonLdGraph
        pageSchema={{
          '@type': 'WebPage',
          name: 'Case Results',
          url: 'https://toddflaw.com/results/',
        }}
      />

      {/* PAGE HERO */}
      <section className="page-hero on-dark">
        <div className="grid-lines"></div>
        <div className="container">
          <div className="breadcrumb reveal visible">
            <Link href="/">Home</Link>
            <span className="sep">/</span>Results
          </div>
          <h1 className="h-xl reveal visible">Results that<br /><span className="gold">speak for themselves</span></h1>
          <p className="lead reveal visible" style={{ marginTop: '24px' }}>
            Employment and consumer protection attorneys with nearly $1 billion recovered for clients in California, Ohio, Illinois, and Pennsylvania.
          </p>
        </div>
      </section>

      {/* RESULTS: docket cards with filters */}
      <section className="bg-bone" id="results">
        <div className="container">
          <div className="reveal visible">
            <span className="eyebrow">Track Record</span>
            <h2 className="h-lg" style={{ marginTop: '20px' }}>Proven where<br />it counts</h2>
          </div>
          <ResultsGrid />
        </div>
      </section>

      {/* CTA */}
      <section className="cta-band on-dark" id="contact">
        <div className="container">
          <div className="cta-inner">
            <div className="reveal visible">
              <span className="eyebrow">Free Consultation</span>
              <h2 className="h-lg" style={{ margin: '20px 0 24px' }}>Start fighting<br />back <span className="gold">today.</span></h2>
              <p className="lead" style={{ marginBottom: '32px' }}>
                Many cases are handled on contingency, meaning you pay nothing unless we win. Speak directly with an attorney about your case.
              </p>
              <a href="tel:323-690-1688" className="btn btn-outline">Call 323-690-1688</a>
            </div>
            <div className="form-card reveal visible">
              <h3>Schedule a Free Case Review</h3>
              <p className="form-sub">Prompt, straightforward feedback. No obligation.</p>
              <LeadForm />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
