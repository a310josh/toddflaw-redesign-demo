import { fetchPage } from '@/lib/wp';
import JsonLdGraph from '@/app/components/JsonLdGraph';
import LeadForm from '@/app/components/LeadForm';
import { rewriteInternalLinks } from '../../lib/links';

export const revalidate = 3600;

export async function generateMetadata() {
  const page = await fetchPage(60461).catch(() => null);
  return {
    title: page?.title || 'Employment Law',
    description: page?.excerpt?.replace(/<[^>]*>/g, '').slice(0, 160) ||
      'Employment law representation for wrongful termination, discrimination, wage and hour, harassment, and class actions.',
    alternates: { canonical: '/employment-law/' },
  };
}

export default async function EmploymentLawPage() {
  const page = await fetchPage(60461).catch(() => null);

  return (
    <>
      <JsonLdGraph
        pageSchema={{
          '@type': 'WebPage',
          name: page?.title || 'Employment Law',
          url: 'https://toddflaw.com/employment-law/',
        }}
      />
      <section className="section page-hero bg-navy">
        <div className="container">
          <h1>{page?.title || 'Employment Law'}</h1>
          {page?.excerpt && (
            <p
              dangerouslySetInnerHTML={{ __html: page.excerpt }}
              style={{ maxWidth: '640px', opacity: 0.85 }}
            />
          )}
        </div>
      </section>
      <section className="section">
        <div className="container">
          {page?.content ? (
            <div className="wp-content" dangerouslySetInnerHTML={{ __html: rewriteInternalLinks(page.content) }} />
          ) : (
            <p>Loading content...</p>
          )}
        </div>
      </section>
      <section className="cta-form section bg-navy">
        <div className="container" style={{ maxWidth: '720px' }}>
          <h2 style={{ color: 'var(--gold)' }}>Employment Law Case Review</h2>
          <p>Tell us what happened. Free evaluation.</p>
          <LeadForm />
        </div>
      </section>
    </>
  );
}
