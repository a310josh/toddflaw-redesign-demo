import { fetchPage } from '@/lib/wp';
import JsonLdGraph from '@/app/components/JsonLdGraph';
import LeadForm from '@/app/components/LeadForm';
import { rewriteInternalLinks } from '../../lib/links';

export const revalidate = 3600;

export async function generateMetadata() {
  const page = await fetchPage(58456).catch(() => null);
  return {
    title: page?.title || 'Consumer Rights',
    description: page?.excerpt?.replace(/<[^>]*>/g, '').slice(0, 160) ||
      'Consumer protection and class action representation for unfair debt collection, robocalls, data breaches, and false advertising.',
    alternates: { canonical: '/consumer-rights/' },
  };
}

export default async function ConsumerRightsPage() {
  const page = await fetchPage(58456).catch(() => null);

  return (
    <>
      <JsonLdGraph
        pageSchema={{
          '@type': 'WebPage',
          name: page?.title || 'Consumer Rights',
          url: 'https://toddflaw.com/consumer-rights/',
        }}
      />
      <section className="section page-hero bg-navy">
        <div className="container">
          <h1>{page?.title || 'Consumer Rights'}</h1>
          {page?.excerpt && (
            <p
              dangerouslySetInnerHTML={{ __html: page.excerpt }}
              style={{ maxWidth: '640px', opacity: 0.85 }}
            />
          )}
        </div>
      </section>
      <section className="section">
        <div className="container">
          {page?.content ? (
            <div className="wp-content" dangerouslySetInnerHTML={{ __html: rewriteInternalLinks(page.content) }} />
          ) : (
            <p>Loading content...</p>
          )}
        </div>
      </section>
      <section className="cta-form section bg-navy">
        <div className="container" style={{ maxWidth: '720px' }}>
          <h2 style={{ color: 'var(--gold)' }}>Consumer Rights Case Review</h2>
          <p>Tell us what happened. Free evaluation.</p>
          <LeadForm />
        </div>
      </section>
    </>
  );
}
