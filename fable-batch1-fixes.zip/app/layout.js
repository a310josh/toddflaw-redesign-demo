import { Archivo, Inter } from 'next/font/google';
import './globals.css';
import './templates.css';
import Header from './components/Header';
import Footer from './components/Footer';
import MobileCallBar from './components/MobileCallBar';
import Analytics from './components/Analytics';
import JsonLdGraph from './components/JsonLdGraph';

const archivo = Archivo({
  subsets: ['latin'],
  weight: ['500', '600', '700', '800', '900'],
  variable: '--font-display',
  display: 'swap',
  fallback: ['sans-serif'],
});

const inter = Inter({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-body',
  display: 'swap',
  fallback: ['sans-serif'],
});

export const metadata = {
  metadataBase: new URL('https://toddflaw.com'),
  title: {
    default: 'Employee Rights & Consumer Protection | Law Offices of Todd M. Friedman, P.C.',
    template: '%s | Law Offices of Todd M. Friedman, P.C.',
  },
  description:
    'Employment law and consumer protection attorneys serving California, Ohio, Illinois, and Pennsylvania. Nearly $1 billion recovered for clients.',
  openGraph: {
    siteName: 'Law Offices of Todd M. Friedman, P.C.',
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${archivo.variable} ${inter.variable}`}>
      <body>
        <JsonLdGraph />
        <Analytics />
        <Header />
        <main>{children}</main>
        <Footer />
        <MobileCallBar />
      </body>
    </html>
  );
}
