import Link from 'next/link';
import JsonLdGraph from '../components/JsonLdGraph';
import LeadForm from '../components/LeadForm';
import TeamGrid from './TeamGrid';

export const metadata = {
  title: 'About Our Firm',
  description:
    'Learn about the attorneys at the Law Offices of Todd M. Friedman, P.C. One mission across four states: protect your rights with aggressive, honest representation.',
  alternates: { canonical: '/about/' },
};

const LOGO_WALL = [
  { src: 'https://toddflaw.com/wp-content/uploads/2026/01/Superlawyers-10-years.png', alt: 'Super Lawyers 10 Years', tall: true },
  { src: 'https://toddflaw.com/wp-content/uploads/2026/01/Superlawyers-1.png', alt: 'Super Lawyers', tall: true },
  { src: 'https://toddflaw.com/wp-content/uploads/2026/01/Superlawyers-Top-100.png', alt: 'Super Lawyers Top 100', tall: true },
  { src: 'https://toddflaw.com/wp-content/uploads/2025/03/partner-5-1-2.png', alt: 'Professional association' },
  { src: 'https://toddflaw.com/wp-content/uploads/2025/03/partner-3-1-2.png', alt: 'Professional association' },
  { src: 'https://toddflaw.com/wp-content/uploads/2025/03/partner-1-1-2.png', alt: 'Professional association' },
  { src: 'https://toddflaw.com/wp-content/uploads/2025/03/partner-12-1-2.png', alt: 'Professional association' },
  { src: 'https://toddflaw.com/wp-content/uploads/2025/03/partner-4-1-2.png', alt: 'Professional association' },
  { src: 'https://toddflaw.com/wp-content/uploads/2025/03/partner-10-1-2.png', alt: 'Professional association' },
  { src: 'https://toddflaw.com/wp-content/uploads/2025/03/partner-8-1-2.png', alt: 'Professional association' },
];

const DIFFERENTIATORS = [
  {
    title: '11-Time Super Lawyer',
    body: 'Todd Friedman has been named a Super Lawyer every year from 2016 through 2026, a distinction of professional achievement and peer recognition.',
    delay: '.05s',
  },
  {
    title: 'Speak Directly With Your Attorney',
    body: 'Todd evaluates your situation personally and gives prompt, straightforward feedback, saving you time and alleviating uncertainty.',
    delay: '.1s',
  },
  {
    title: 'A+ BBB Rating',
    body: 'Accredited by the Better Business Bureau since 2010 with the highest possible rating.',
    delay: '.15s',
  },
  {
    title: 'Resources to Take On Powerful Opponents',
    body: 'We are strong advocates with the firepower necessary to challenge major corporations and win.',
    delay: '.2s',
  },
];

export default function AboutPage() {
  return (
    <>
      <JsonLdGraph
        pageSchema={{
          '@type': 'AboutPage',
          name: 'About Us',
          url: 'https://toddflaw.com/about/',
        }}
      />

      {/* PAGE HERO */}
      <section className="page-hero on-dark">
        <div className="grid-lines"></div>
        <div className="container">
          <div className="breadcrumb reveal visible">
            <Link href="/">Home</Link>
            <span className="sep">/</span>About Us
          </div>
          <h1 className="h-xl reveal visible">The firm that<br /><span className="gold">fights back.</span></h1>
          <p className="lead reveal visible" style={{ marginTop: '24px' }}>
            One mission across four states: protect your rights with aggressive, honest representation.
          </p>
        </div>
      </section>

      {/* LOGO WALL */}
      <div className="logo-wall">
        <div className="container">
          <div className="lw-label">Recognition, Memberships &amp; Ratings</div>
          <div className="lw-grid">
            {LOGO_WALL.map((logo, i) => (
              <img key={i} className={logo.tall ? 'tall' : undefined} src={logo.src} alt={logo.alt} />
            ))}
          </div>
        </div>
      </div>

      {/* WHO WE ARE */}
      <section>
        <div className="container">
          <div className="who-grid">
            <div className="who-img reveal visible">
              <img src="https://toddflaw.com/wp-content/uploads/2025/03/Todd-headhsot-highres.jpg" alt="Todd M. Friedman" />
            </div>
            <div className="reveal visible">
              <span className="eyebrow">Who We Are</span>
              <h2 className="h-lg" style={{ margin: '20px 0 22px' }}>Why choose<br />this firm?</h2>
              <p className="lead">
                With so many law firms in Southern California and throughout the United States, here is what sets the Law Offices of Todd M. Friedman apart:
              </p>
              <div className="diff-list reveal-stagger visible">
                {DIFFERENTIATORS.map((item) => (
                  <div key={item.title} className="diff-item" style={{ transitionDelay: item.delay }}>
                    <div className="diff-check">&#10003;</div>
                    <div>
                      <h3>{item.title}</h3>
                      <p>{item.body}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <div className="stats on-dark">
        <div className="stats-grid">
          <div className="stat"><div className="stat-num">~$1B</div><div className="stat-label">Recovered for Clients</div></div>
          <div className="stat"><div className="stat-num">20+</div><div className="stat-label">Years of Experience</div></div>
          <div className="stat"><div className="stat-num">10</div><div className="stat-label">Attorneys on Your Side</div></div>
          <div className="stat"><div className="stat-num">4</div><div className="stat-label">States Served</div></div>
        </div>
      </div>

      {/* TEAM */}
      <section className="bg-bone" id="team">
        <div className="container">
          <div className="reveal visible">
            <span className="eyebrow">Our Attorneys</span>
            <h2 className="h-lg" style={{ marginTop: '20px' }}>Meet the team</h2>
          </div>
          <TeamGrid />

          {/* TESTIMONIAL: Spotlight */}
          <div className="spotlight reveal visible" style={{ marginTop: '64px', marginBottom: 0 }}>
            <blockquote>
              I could literally write a book on how excellent Todd and his team are. Proactive, relentless in fighting for a fair result, and amazing customer service. He actually took the time to reach out personally.
            </blockquote>
            <div className="s-meta">
              <div className="s-avatar">LY</div>
              <div className="s-who"><strong>LanNesha Y.</strong><span>Verified Google Review</span></div>
              <div className="s-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="cta-band on-dark" id="contact">
        <div className="container">
          <div className="cta-inner">
            <div className="reveal visible">
              <span className="eyebrow">Free Consultation</span>
              <h2 className="h-lg" style={{ margin: '20px 0 24px' }}>Contact us and<br />start <span className="gold">fighting back.</span></h2>
              <p className="lead" style={{ marginBottom: '32px' }}>
                If you have experienced a violation of your rights, call us or fill out the form. Not ready to commit? See what our clients say about working with us.
              </p>
              <a href="tel:323-690-1688" className="btn btn-outline">Call 323-690-1688</a>
            </div>
            <div className="form-card reveal visible">
              <h3>Schedule a Free Case Review</h3>
              <p className="form-sub">Prompt, straightforward feedback. No obligation.</p>
              <LeadForm />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
