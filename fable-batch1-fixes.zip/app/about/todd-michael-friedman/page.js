import Link from 'next/link';
import JsonLdGraph from '../../components/JsonLdGraph';
import LeadForm from '../../components/LeadForm';
import AwardTimeline from './AwardTimeline';

export const metadata = {
  title: 'Todd Michael Friedman, Founder & Managing Attorney',
  description:
    'Founder and managing attorney Todd M. Friedman: 11-time Super Lawyer, nearly $1 billion recovered for employees and consumers.',
  alternates: { canonical: '/about/todd-michael-friedman/' },
};

const MEMBERSHIP_LOGOS = [
  'https://toddflaw.com/wp-content/uploads/2025/03/partner-5-1-2.png',
  'https://toddflaw.com/wp-content/uploads/2025/03/partner-3-1-2.png',
  'https://toddflaw.com/wp-content/uploads/2025/03/partner-1-1-2.png',
  'https://toddflaw.com/wp-content/uploads/2025/03/partner-12-1-2.png',
  'https://toddflaw.com/wp-content/uploads/2025/03/partner-4-1-2.png',
  'https://toddflaw.com/wp-content/uploads/2025/03/partner-10-1-2.png',
  'https://toddflaw.com/wp-content/uploads/2025/03/partner-8-1-2.png',
];

const MINI_RESULTS = [
  { amt: '$150M', lbl: 'GM / LG battery defect class action, 100,000+ vehicle owners', delay: '.05s' },
  { amt: '$100M', lbl: 'DoorDash driver misclassification, landmark gig-economy settlement', delay: '.1s' },
  { amt: '$34M', lbl: 'Chase TCPA class action, 32 million class members', delay: '.15s' },
  { amt: '$13M', lbl: 'HSBC call-recording privacy class action under Cal. Penal Code § 632.7', delay: '.2s' },
];

export default function ToddMichaelFriedmanPage() {
  return (
    <>
      <JsonLdGraph
        pageSchema={{
          '@type': ['Person', 'Attorney'],
          '@id': 'https://toddflaw.com/about/todd-michael-friedman/#person',
          name: 'Todd Michael Friedman',
          jobTitle: 'Founder & Managing Attorney',
          url: 'https://toddflaw.com/about/todd-michael-friedman/',
          image: 'https://toddflaw.com/wp-content/uploads/2025/03/Todd-headhsot-highres.jpg',
          worksFor: { '@id': 'https://toddflaw.com/#organization' },
          award: 'Super Lawyers, 2016 to 2026',
          knowsAbout: ['Employment Law', 'Consumer Protection', 'Class Actions', 'TCPA', 'FDCPA', 'FCRA', 'Lemon Law'],
        }}
      />

      {/* PROFILE HERO */}
      <section className="profile-hero on-dark">
        <div className="container">
          <div className="ph-grid">
            <div className="ph-text">
              <div className="breadcrumb reveal visible">
                <Link href="/">Home</Link>
                <span className="sep">/</span>
                <Link href="/about/">About</Link>
                <span className="sep">/</span>Todd Michael Friedman
              </div>
              <span className="eyebrow reveal visible">Founder &middot; Managing Attorney</span>
              <h1 className="ph-name reveal visible" style={{ marginTop: '22px' }}>
                Todd<br />Michael<br /><span className="gold">Friedman</span>
              </h1>
              <div className="ph-creds reveal visible">
                <span>Super Lawyer 2016 to 2026</span>
                <span>20+ Years</span>
                <span>CA &middot; OH &middot; IL &middot; PA</span>
              </div>
            </div>
            <div className="ph-photo reveal visible">
              <img src="https://toddflaw.com/wp-content/uploads/2025/03/Todd-headhsot-highres.jpg" alt="Todd Michael Friedman" />
              <div className="ph-badge">11&times; Super<br />Lawyer</div>
            </div>
          </div>
        </div>
      </section>

      {/* BIO */}
      <section style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="bio-layout">
            <div className="bio-copy reveal visible">
              <span className="eyebrow">Biography</span>
              <h2 style={{ marginTop: '20px' }}>Why Todd fights</h2>
              <p>
                Todd M. Friedman became a lawyer more than 20 years ago because he got tired of seeing regular, hard-working people get taken advantage of by the system. Employers, creditors, negligent drivers, telemarketers, and medical professionals seem to have all the power, and honest people regularly face a system too large and too complicated to fight back against alone.
              </p>
              <div className="drop-quote">
                &ldquo;You will leave my firm feeling that your interests were adequately and vigorously protected.&rdquo;
              </div>
              <p>
                At the Law Offices of Todd M. Friedman, P.C., that imbalance is the entire point of the practice. Todd built the firm to level the playing field, securing nearly $1 billion in recoveries for employees and consumers wronged by corporations, employers, and debt collectors.
              </p>
              <h2>A national practice</h2>
              <p>
                Headquartered in Los Angeles with offices in Chicago, Cleveland, and King of Prussia, Todd leads a team of ten attorneys handling employment law, consumer protection, class actions, lemon law, personal injury, and business litigation across four states.
              </p>

              {/* CASE RESULT: verdict stamp */}
              <div className="verdict">
                <div className="v-amt">$100M<small>Settlement</small></div>
                <div className="v-body">
                  <strong>Marko v. DoorDash, Inc.</strong>
                  <p>
                    The largest gig-economy worker class settlement in U.S. history at approval. Todd&apos;s firm served as class counsel for drivers in California and Massachusetts.
                  </p>
                </div>
              </div>

              <p>
                His class action work includes some of the most consequential consumer and employment settlements in recent history: the $150 million GM/LG battery defect settlement and a $34 million TCPA settlement against Chase covering more than 32 million class members.
              </p>
              <h2>Recognition</h2>
              <p>
                Todd has been named a Super Lawyer eleven consecutive years (2016 to 2026), and the firm has held an A+ rating from the Better Business Bureau since its accreditation in 2010. He has been featured by CBS News and Spectrum News on emerging consumer protection issues, including the Uber 1099 identity theft crisis.
              </p>
            </div>
            <aside className="bio-side">
              <div className="side-card">
                <h3 style={{ color: 'var(--navy)' }}>Awards &amp; Badges</h3>
                <div className="side-badges">
                  <img src="https://toddflaw.com/wp-content/uploads/2026/01/Superlawyers-10-years.png" alt="Super Lawyers 10 Years" />
                  <img src="https://toddflaw.com/wp-content/uploads/2026/01/Superlawyers-1.png" alt="Super Lawyers" />
                  <img src="https://toddflaw.com/wp-content/uploads/2026/01/Superlawyers-Top-100.png" alt="Super Lawyers Top 100" />
                </div>
              </div>
              <div className="side-card dark on-dark">
                <h3>Practice Focus</h3>
                <ul>
                  <li>Employment Law</li>
                  <li>Consumer Protection</li>
                  <li>Class Actions</li>
                  <li>TCPA / FDCPA / FCRA</li>
                  <li>Lemon Law</li>
                </ul>
              </div>
              <div className="side-card">
                <h3 style={{ color: 'var(--navy)' }}>Recognition</h3>
                <ul>
                  <li>Super Lawyers, 2016 to 2026</li>
                  <li>BBB A+ Rating since 2010</li>
                  <li>Featured: CBS News</li>
                  <li>Featured: Spectrum News</li>
                </ul>
              </div>
              <div className="side-cta">
                <h3 className="h-md">Talk to Todd</h3>
                <p>Free consultation. Direct attorney feedback.</p>
                <a href="#contact" className="btn">Free Case Review</a>
              </div>
            </aside>
          </div>
        </div>
      </section>

      {/* LOGO WALL */}
      <div className="logo-wall">
        <div className="container">
          <div className="lw-label">Memberships &amp; Associations</div>
          <div className="lw-grid">
            {MEMBERSHIP_LOGOS.map((src) => (
              <img key={src} src={src} alt="Professional association" />
            ))}
          </div>
        </div>
      </div>

      {/* AWARDS TIMELINE */}
      <section className="bg-bone">
        <div className="container">
          <div className="reveal visible">
            <span className="eyebrow">Peer Recognition</span>
            <h2 className="h-lg" style={{ marginTop: '20px' }}>Eleven straight years<br />of Super Lawyers</h2>
          </div>
          <AwardTimeline />
        </div>
      </section>

      {/* NOTABLE RESULTS */}
      <section className="results-section on-dark" style={{ background: 'var(--navy-deep)' }}>
        <div className="container">
          <div className="reveal visible">
            <span className="eyebrow">Track Record</span>
            <h2 className="h-lg" style={{ marginTop: '20px' }}>Results Todd<br />has led</h2>
          </div>
          <div className="mini-results reveal-stagger visible">
            {MINI_RESULTS.map((r) => (
              <div key={r.amt} className="mini-result" style={{ transitionDelay: r.delay }}>
                <div className="amt">{r.amt}</div>
                <div className="lbl">{r.lbl}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="cta-band on-dark" id="contact">
        <div className="container">
          <div className="cta-inner">
            <div className="reveal visible">
              <span className="eyebrow">Free Consultation</span>
              <h2 className="h-lg" style={{ margin: '20px 0 24px' }}>Todd can<br /><span className="gold">help.</span></h2>
              <p className="lead" style={{ marginBottom: '32px' }}>
                Speak directly with Todd about your case. Prompt, straightforward feedback, with many cases handled on contingency.
              </p>
              <a href="tel:323-690-1688" className="btn btn-outline">Call 323-690-1688</a>
            </div>
            <div className="form-card reveal visible">
              <h3>Schedule a Free Case Review</h3>
              <p className="form-sub">No obligation. No upfront costs on contingency cases.</p>
              <LeadForm />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
