'use client';
import { useState } from 'react';

const YEARS = [2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026];

const NOTES = {
  2016: 'First selection to Super Lawyers, recognizing a decade of consumer and employment advocacy already behind the firm.',
  2017: "Second consecutive selection as the firm's class action practice expanded nationally.",
  2018: 'Selection year in which major wage-and-hour class settlements received final approval, including a $2.4M valet misclassification class.',
  2019: 'Continued recognition as the firm pressed TCPA and privacy class actions against national banks.',
  2020: 'Selection amid landmark gig-economy litigation, including the DoorDash misclassification case.',
  2021: 'Sixth straight selection; the firm expands its multi-state employment law footprint.',
  2022: 'The DoorDash settlement receives final approval: $100M, the largest gig-worker class settlement in U.S. history at the time.',
  2023: 'Eighth consecutive selection; consumer privacy and FCRA practice grows.',
  2024: 'Ninth consecutive selection, with the GM/LG battery defect litigation advancing toward its $150M settlement.',
  2025: 'Tenth straight year: a Super Lawyers decade, an honor few attorneys reach.',
  2026: 'A decade-plus of continuous peer recognition. Fewer than 5% of attorneys are selected in a given year. Eleven consecutive selections reflects sustained excellence, not a single good season.',
};

const NTH = ['1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th'];

export default function AwardTimeline() {
  const [year, setYear] = useState(2026);

  return (
    <>
      <div className="tl-rail reveal visible" id="tlRail">
        {YEARS.map((y) => (
          <button
            key={y}
            className={`tl-year${y === year ? ' active' : ''}`}
            onClick={() => setYear(y)}
          >
            {y}
          </button>
        ))}
      </div>
      <div className="tl-detail" id="tlDetail" key={year}>
        <h3>{year}: Super Lawyer, {NTH[YEARS.indexOf(year)]} Consecutive Selection</h3>
        <p>{NOTES[year]}</p>
      </div>
    </>
  );
}
