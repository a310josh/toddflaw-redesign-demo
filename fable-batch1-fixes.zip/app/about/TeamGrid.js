'use client';
import { useState } from 'react';
import Link from 'next/link';

const FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'partner', label: 'Partners' },
  { key: 'attorney', label: 'Attorneys' },
  { key: 'associate', label: 'Associates' },
];

const TEAM = [
  {
    name: 'Todd Michael Friedman',
    role: 'Founding Partner',
    roleKey: 'partner',
    href: '/about/todd-michael-friedman/',
    photo: 'https://toddflaw.com/wp-content/uploads/2025/03/Todd-headhsot-highres.jpg',
    delay: '.05s',
  },
  { name: 'Adrian R. Bacon', role: 'Partner', roleKey: 'partner', href: '#', initials: 'AB', delay: '.1s' },
  { name: 'Cynthia Levin', role: 'Attorney', roleKey: 'attorney', href: '#', initials: 'CL', delay: '.15s' },
  { name: 'David B. Levin', role: 'Attorney', roleKey: 'attorney', href: '#', initials: 'DL', delay: '.2s' },
  { name: 'Steven G. Perry', role: 'Associate Attorney', roleKey: 'associate', href: '#', initials: 'SP', delay: '.25s' },
  { name: 'Meghan Elizabeth George', role: 'Associate Attorney', roleKey: 'associate', href: '#', initials: 'MG', delay: '.3s' },
  { name: 'Gerardo Sosa', role: 'Associate Attorney', roleKey: 'associate', href: '#', initials: 'GS', delay: '.35s' },
  { name: 'Matt Snyder', role: 'Associate Attorney', roleKey: 'associate', href: '#', initials: 'MS', delay: '.4s' },
  { name: 'Tom Wheeler', role: 'Associate Attorney', roleKey: 'associate', href: '#', initials: 'TW', delay: '.45s' },
  { name: 'Andrew Brashler', role: 'Associate Attorney', roleKey: 'associate', href: '#', initials: 'AB', delay: '.5s' },
];

export default function TeamGrid() {
  const [filter, setFilter] = useState('all');

  return (
    <>
      <div className="team-filters" id="teamFilters">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            className={`chip${filter === f.key ? ' active' : ''}`}
            onClick={() => setFilter(f.key)}
          >
            {f.label}
          </button>
        ))}
      </div>
      <div className="team-grid reveal-stagger visible" id="teamGrid">
        {TEAM.map((member) => {
          const hidden = filter !== 'all' && member.roleKey !== filter;
          const card = (
            <>
              <div className="tc-photo">
                {member.photo ? (
                  <img src={member.photo} alt={member.name} />
                ) : (
                  <div className="tc-initials">{member.initials}</div>
                )}
              </div>
              <div className="tc-body">
                <h3>{member.name}</h3>
                <div className="tc-role">{member.role}</div>
                <span className="tc-link">View Bio <span>&rarr;</span></span>
              </div>
            </>
          );
          const className = `team-card${hidden ? ' hide' : ''}`;
          const style = { transitionDelay: member.delay };
          return member.href !== '#' ? (
            <Link key={member.name + member.role} className={className} data-role={member.roleKey} href={member.href} style={style}>
              {card}
            </Link>
          ) : (
            <a key={member.name + member.role} className={className} data-role={member.roleKey} href="#" style={style}>
              {card}
            </a>
          );
        })}
      </div>
    </>
  );
}
