'use client';
import { useState } from 'react';

const OFFICES = [
  {
    city: 'Los Angeles',
    tel: '818-619-3774',
    telDisplay: '(818) 619-3774',
    address: '23586 Calabasas Rd., Suite 105 · Calabasas, CA 91302',
    img: 'https://toddflaw.com/wp-content/uploads/2021/02/view-of-los-angeles-skyline-at-sunset-PW3TEFM.jpg',
    alt: 'Los Angeles',
  },
  {
    city: 'Cleveland',
    tel: '216-284-7628',
    telDisplay: '(216) 284-7628',
    address: '600 Superior Ave E, Suite 1300 · Cleveland, OH 44114',
    img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/Cleveland_skyline_from_Lakewood_Park%2C_January_2026.jpg/1920px-Cleveland_skyline_from_Lakewood_Park%2C_January_2026.jpg',
    alt: 'Cleveland',
  },
  {
    city: 'Chicago',
    tel: '312-815-2024',
    telDisplay: '(312) 815-2024',
    address: '555 Skokie Blvd., Suite 500 · Northbrook, IL 60062',
    img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Chicago_River_ferry_b.jpg/1920px-Chicago_River_ferry_b.jpg',
    alt: 'Chicago',
  },
  {
    city: 'King of Prussia',
    tel: '610-665-3086',
    telDisplay: '(610) 665-3086',
    address: '840 First Ave, Suite 400 · King of Prussia, PA 19406',
    img: 'https://commons.wikimedia.org/wiki/Special:FilePath/Philadelphia_skyline_20240528_(cropped).jpg?width=1920',
    alt: 'King of Prussia',
  },
];

export default function OfficeExplorer() {
  const [active, setActive] = useState(0);

  return (
    <section className="offices-x on-dark" id="offices">
      <div className="ox-list">
        <span className="eyebrow">Four Offices, One Standard</span>
        {OFFICES.map((office, i) => (
          <div
            key={office.city}
            className={`ox-item${i === active ? ' active' : ''}`}
            tabIndex={0}
            onMouseEnter={() => setActive(i)}
            onFocus={() => setActive(i)}
            onClick={() => setActive(i)}
          >
            <h3>{office.city}</h3>
            <a className="ox-tel" href={`tel:${office.tel}`}>{office.telDisplay}</a>
            <address>{office.address}</address>
          </div>
        ))}
      </div>
      <div className="ox-media">
        {OFFICES.map((office, i) => (
          <img
            key={office.city}
            className={i === active ? 'active' : ''}
            src={office.img}
            alt={office.alt}
            loading={i === 0 ? undefined : 'lazy'}
          />
        ))}
      </div>
    </section>
  );
}
