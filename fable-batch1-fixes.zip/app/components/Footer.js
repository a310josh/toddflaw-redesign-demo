import Link from 'next/link';
import { FIRM } from '../../lib/wp';
import OfficeExplorer from './OfficeExplorer';

export default function Footer() {
  return (
    <>
      <OfficeExplorer />
      <footer className="footer">
        <div className="container">
          <div className="footer-grid">
            <div>
              <div className="footer-logo">
                <img src={FIRM.logo} alt="TMF Law" />
              </div>
              <p className="footer-desc">
                A consumer protection and employment law firm serving California, Ohio, Pennsylvania, and Illinois. Free consultations, contingency representation.
              </p>
            </div>
            <div>
              <h4>Practice Areas</h4>
              <Link href="/employment-law/">Employment Law</Link>
              <Link href="/consumer-rights/">Consumer Rights</Link>
              <Link href="/results/">Class Actions</Link>
              <Link href="/contact/">Lemon Law</Link>
              <Link href="/contact/">Personal Injury</Link>
            </div>
            <div>
              <h4>Firm</h4>
              <Link href="/about/">About Us</Link>
              <Link href="/about/todd-michael-friedman/">Attorneys</Link>
              <Link href="/results/">Results</Link>
              <Link href="/blog/">Blog</Link>
              <Link href="/contact/">Contact</Link>
            </div>
            <div>
              <h4>Talk to Us</h4>
              <a href={`tel:${FIRM.phone}`}>{FIRM.phone}</a>
              <Link href="/contact/">Free Case Evaluation</Link>
              <a href="#offices">Office Locations</a>
              <a href={FIRM.sameAs[0]} target="_blank" rel="noopener noreferrer">LinkedIn</a>
              <a href={FIRM.sameAs[1]} target="_blank" rel="noopener noreferrer">Facebook</a>
            </div>
          </div>
          <div className="footer-bottom">
            <span>&copy; {new Date().getFullYear()} {FIRM.name}. All Rights Reserved.</span>
            <div className="links">
              <Link href="/privacy-policy/">Privacy Policy</Link>
              <Link href="/disclaimer/">Disclaimer</Link>
              <Link href="/terms-and-conditions/">T&amp;Cs</Link>
              <Link href="/sitemap/">Sitemap</Link>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}
