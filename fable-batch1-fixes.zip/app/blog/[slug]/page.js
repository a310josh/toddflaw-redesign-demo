import { fetchPostBySlug } from '@/lib/wp';
import { notFound } from 'next/navigation';
import JsonLdGraph from '../../components/JsonLdGraph';
import { rewriteInternalLinks } from '../../../lib/links';

export const revalidate = 3600;

export async function generateMetadata({ params }) {
  const { slug } = await params;
  const post = await fetchPostBySlug(slug);
  if (!post) return { title: 'Post Not Found' };
  return {
    title: post.title,
    description: post.excerpt?.replace(/<[^>]*>/g, '').slice(0, 160) || '',
    alternates: { canonical: `/blog/${slug}/` },
  };
}

export default async function BlogPostPage({ params }) {
  const { slug } = await params;
  const post = await fetchPostBySlug(slug);
  if (!post) notFound();

  return (
    <>
      <JsonLdGraph
        pageSchema={{
          '@type': 'BlogPosting',
          headline: post.title,
          url: `https://toddflaw.com/blog/${post.slug}/`,
          datePublished: post.date,
          dateModified: post.modified,
        }}
      />
      <article className="section">
        <div className="container" style={{ maxWidth: '780px' }}>
          <div className="post-header">
            <div className="post-card-meta">
              {post.categoryNames.slice(0, 3).map((c) => (
                <span key={c} className="post-card-cat">{c}</span>
              ))}
              <time dateTime={post.date}>
                {new Date(post.date).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </time>
            </div>
            <h1>{post.title}</h1>
          </div>
          {post.featuredMedia && (
            <img
              src={post.featuredMedia}
              alt=""
              style={{ width: '100%', borderRadius: 'var(--radius)', marginBottom: '2rem' }}
            />
          )}
          <div
            className="wp-content"
            dangerouslySetInnerHTML={{ __html: rewriteInternalLinks(post.content) }}
          />
        </div>
      </article>
    </>
  );
}
