import Link from 'next/link';
import JsonLdGraph from '../components/JsonLdGraph';
import LeadForm from '../components/LeadForm';

export const metadata = {
  title: 'Contact Us',
  description:
    'Contact the Law Offices of Todd M. Friedman, P.C. for a free case evaluation. Offices in California, Ohio, Illinois, and Pennsylvania.',
  alternates: { canonical: '/contact/' },
};

const OFFICES = [
  {
    label: 'Los Angeles, CA Office',
    addressLines: ['23586 Calabasas Rd., Suite 105', 'Calabasas, CA 91302'],
    locality: 'Calabasas',
    region: 'CA',
    postal: '91302',
    street: '23586 Calabasas Rd., Suite 105',
    tel: '818-619-3774',
    telDisplay: '(818) 619-3774',
    img: 'https://toddflaw.com/wp-content/uploads/2021/02/view-of-los-angeles-skyline-at-sunset-PW3TEFM.jpg',
    alt: 'Los Angeles skyline',
  },
  {
    label: 'Cleveland, OH Office',
    addressLines: ['600 Superior Ave E, Suite 1300', 'Cleveland, OH 44114'],
    locality: 'Cleveland',
    region: 'OH',
    postal: '44114',
    street: '600 Superior Ave E, Suite 1300',
    tel: '216-284-7628',
    telDisplay: '(216) 284-7628',
    img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/Cleveland_skyline_from_Lakewood_Park%2C_January_2026.jpg/1920px-Cleveland_skyline_from_Lakewood_Park%2C_January_2026.jpg',
    alt: 'Cleveland skyline',
  },
  {
    label: 'Chicago, IL Office',
    addressLines: ['555 Skokie Blvd., Suite 500', 'Northbrook, IL 60062'],
    locality: 'Northbrook',
    region: 'IL',
    postal: '60062',
    street: '555 Skokie Blvd., Suite 500',
    tel: '312-815-2024',
    telDisplay: '(312) 815-2024',
    img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Chicago_River_ferry_b.jpg/1920px-Chicago_River_ferry_b.jpg',
    alt: 'Chicago skyline',
  },
  {
    label: 'King of Prussia, PA Office',
    addressLines: ['840 First Ave, Suite 400', 'King of Prussia, PA 19406'],
    locality: 'King of Prussia',
    region: 'PA',
    postal: '19406',
    street: '840 First Ave, Suite 400',
    tel: '610-665-3086',
    telDisplay: '(610) 665-3086',
    img: 'https://commons.wikimedia.org/wiki/Special:FilePath/Philadelphia_skyline_20240528_(cropped).jpg?width=1920',
    alt: 'King of Prussia town center',
  },
];

export default function ContactPage() {
  return (
    <>
      <JsonLdGraph
        pageSchema={[
          {
            '@type': 'ContactPage',
            name: 'Contact Us',
            url: 'https://toddflaw.com/contact/',
          },
          ...OFFICES.map((o) => ({
            '@type': 'LocalBusiness',
            '@id': `https://toddflaw.com/contact/#office-${o.locality.toLowerCase().replace(/\s+/g, '-')}`,
            name: `Law Offices of Todd M. Friedman, P.C. (${o.label.replace(' Office', '')})`,
            telephone: o.telDisplay,
            parentOrganization: { '@id': 'https://toddflaw.com/#organization' },
            address: {
              '@type': 'PostalAddress',
              streetAddress: o.street,
              addressLocality: o.locality,
              addressRegion: o.region,
              postalCode: o.postal,
              addressCountry: 'US',
            },
          })),
        ]}
      />

      {/* PAGE HERO */}
      <section className="page-hero on-dark">
        <div className="grid-lines"></div>
        <div className="container">
          <div className="breadcrumb reveal visible">
            <Link href="/">Home</Link>
            <span className="sep">/</span>Contact
          </div>
          <h1 className="h-xl reveal visible">Contact us and<br /><span className="gold">start fighting back.</span></h1>
          <p className="lead reveal visible" style={{ marginTop: '24px' }}>
            If you have experienced a violation of your rights, call us or fill out the form. Free consultations, contingency representation.
          </p>
        </div>
      </section>

      {/* FORM + OFFICES */}
      <section className="bg-bone">
        <div className="container">
          <div className="contact-grid">
            <div>
              <span className="eyebrow">Free Consultation</span>
              <h2 className="h-lg" style={{ margin: '20px 0 24px' }}>Schedule a free<br />case review</h2>
              <div className="form-card reveal visible">
                <h3>Schedule a Free Case Review</h3>
                <p className="form-sub">Prompt, straightforward feedback. No obligation.</p>
                <LeadForm />
              </div>
            </div>
            <div>
              <span className="eyebrow">Four Offices, One Standard</span>
              <h2 className="h-lg" style={{ margin: '20px 0 24px' }}>Office<br />locations</h2>
              <div className="contact-offices reveal-stagger visible">
                {OFFICES.map((office, i) => (
                  <div key={office.label} className="office-card" style={{ transitionDelay: `.${i + 1}s` }}>
                    <div className="oc-img">
                      <img src={office.img} alt={office.alt} loading="lazy" />
                    </div>
                    <div className="oc-body">
                      <div className="oc-label">{office.label}</div>
                      <address>
                        {office.addressLines[0]}<br />
                        {office.addressLines[1]}
                      </address>
                      <a className="phone" href={`tel:${office.tel}`}>{office.telDisplay}</a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
