# Design-fidelity fixes for toddflaw-next

All paths are repo-relative. These files replace or add to the master branch.

- `app/templates.css`: Page-specific CSS ported from the reference pages' inline style blocks (about T6, attorney T3, employment-law office cards, index video-feature/split), plus small glue rules (.grid-lines, .contact-grid) and LeadForm styling compatibility inside .form-card. Global stylesheet, not a module.
- `app/layout.js`: Adds the `./templates.css` import; nothing else changed.
- `app/components/OfficeExplorer.js`: New client component porting the reference .offices-x pre-footer verbatim (4 offices with real NAPs and the exact reference imagery); hover/focus/click swap the active office, mirroring tmf.js behavior with React state.
- `app/components/Footer.js`: Now renders OfficeExplorer above the full reference footer (4-column footer-grid plus footer-bottom); all links internal.
- `app/about/page.js`: Full T6 port replacing the WP content dump: grid-lines page hero, logo wall, who-grid with diff-list, stats band, team section, spotlight testimonial, CTA band with LeadForm. Static metadata kept from the previous page values.
- `app/about/TeamGrid.js`: Client island for the role filter chips and the 10-attorney team grid; Todd's card links to /about/todd-michael-friedman/, others are placeholders per the reference.
- `app/about/todd-michael-friedman/page.js`: New T3 attorney profile route: profile hero with 11x badge, verbatim bio, DoorDash verdict stamp, sticky sidebar cards with award badges, membership logo wall, Super Lawyers timeline, mini-results, CTA with LeadForm. Person/Attorney JSON-LD via JsonLdGraph.
- `app/about/todd-michael-friedman/AwardTimeline.js`: Client island for the 2016 to 2026 interactive Super Lawyers timeline, using the years and notes data from the reference page script.
- `app/contact/page.js`: T7 replacing the WP dump: page hero, two-column layout with LeadForm in a .form-card and 4 office .office-card blocks (employment-law card pattern with city imagery), plus ContactPage and per-office LocalBusiness JSON-LD.
- `app/results/page.js`: T8 replacing the WP dump: page hero, filterable docket-grid of results, CTA band with LeadForm.
- `app/results/ResultsGrid.js`: Client island for the All / Employment / Consumer / Class Action / Privacy filter chips and the docket cards, fed by content/results.json (largest result renders as the .feature card).
- `content/results.json`: 12 seeded results extracted from the reference index and employment-law docket cards and marquee (amount, tag, kind, practiceArea, summary).
- `content/testimonials.json`: 5 seeded testimonials from the reference review rail and spotlights, each tagged with a practiceArea.
- `lib/links.js`: rewriteInternalLinks() rewrites absolute https://toddflaw.com/ hrefs in WP HTML to site-relative paths (keeps /wp-content/ media absolute); stripDashes() replaces em/en dashes with hyphens.
- `app/blog/[slug]/page.js`: Applies rewriteInternalLinks to WP post HTML so in-content links stay on this site.
- `app/employment-law/page.js`: Applies rewriteInternalLinks to WP page HTML.
- `app/consumer-rights/page.js`: Applies rewriteInternalLinks to WP page HTML.
